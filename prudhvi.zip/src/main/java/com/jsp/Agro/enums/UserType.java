package com.jsp.Agro.enums;

public enum UserType {
	farmer,

}
